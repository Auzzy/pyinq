def parse(val):
	int(val)

